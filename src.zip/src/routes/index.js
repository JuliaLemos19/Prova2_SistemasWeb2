const express = require('express');
const routes = express.Router();

const AuthController = require('../controllers/authController');
const UsuarioController = require('../controllers/usuarioController');
const ProdutoController = require('../controllers/produtoController'); // <-- 1. IMPORTAR PRODUTOS

// Rota de Login (Não Protegida)
routes.post('/api/auth/login', AuthController.login);

// Rotas de Usuário e Produto (Acesso Protegido - Requer JWT)
routes.use(AuthController.verificaToken); // Protege todas as rotas abaixo com JWT 

// Rotas de Usuário (Desktop App) 
routes.get('/api/usuarios', UsuarioController.index); 
routes.post('/api/usuarios', UsuarioController.create); 
routes.put('/api/usuarios/:id', UsuarioController.update); 
routes.delete('/api/usuarios/:id', UsuarioController.destroy); 

// --- ROTAS DE PRODUTO (Web Site) ---
routes.get('/api/produtos', ProdutoController.index); 
routes.post('/api/produtos', ProdutoController.create); 
routes.put('/api/produtos/:id', ProdutoController.update); 
routes.delete('/api/produtos/:id', ProdutoController.destroy);
// ------------------------------------

module.exports = routes;