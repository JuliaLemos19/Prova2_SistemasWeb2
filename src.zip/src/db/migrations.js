//Julia Lemos
const knex = require('../config/db');

async function createTables() {
  try {
    // Tabela USUARIO
    await knex.schema.hasTable('Usuario').then(async (exists) => {
      if (!exists) {
        await knex.schema.createTable('Usuario', (table) => {
          table.increments('Id').primary();
          table.string('Nome', 100).notNullable().unique();
          table.string('Senha', 255).notNullable(); // 255 para o hash bcrypt
          table.boolean('Status').defaultTo(true).notNullable(); // Ativo/Inativo
        });
        console.log('Tabela Usuario criada!');
      }
    });

    // Tabela PRODUTO
    await knex.schema.hasTable('Produto').then(async (exists) => {
      if (!exists) {
        await knex.schema.createTable('Produto', (table) => {
          table.increments('Id').primary();
          table.string('Nome', 100).notNullable();
          table.decimal('Preco', 10, 2).notNullable();
          table.boolean('Status').defaultTo(true).notNullable(); // Ativo/Inativo

          // Rastreamento: IdUsuarioCadastro
          table.integer('IdUsuarioCadastro')
               .references('Id')
               .inTable('Usuario')
               .notNullable();

          // Rastreamento: IdUsuarioUpdate
          table.integer('IdUsuarioUpdate')
               .references('Id')
               .inTable('Usuario'); // Pode ser nulo no momento da criação
        });
        console.log('Tabela Produto criada!');
      }
    });

  } catch (error) {
    console.error('Erro ao criar as tabelas:', error);
  } finally {
    knex.destroy();
  }
}

createTables();