const express = require('express');
const cors = require('cors'); // <-- 1. IMPORTAR CORS
const routes = require('./routes');
const app = express();
const PORT = 3000;

// Configuração do CORS: Permite que o frontend acesse a API
// Essencial quando o frontend é carregado via arquivo local (file://)
app.use(cors()); // <-- 2. USAR CORS

app.use(express.json());
app.use(routes);

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});