const knex = require('../config/db');
const bcrypt = require('bcryptjs'); // <--- PRECISA SER IMPORTADO AQUI
const jwt = require('jsonwebtoken');
const jwtSecret = 'sua_chave_secreta';

const authController = {
    // --- FUNÇÃO 1: LOGIN (ASYNC) ---
    async login(req, res) {
        const { nome, senha } = req.body;

        if (!nome || !senha) {
            return res.status(400).json({ error: 'Nome e senha são obrigatórios.' });
        }

        try {
            const user = await knex('Usuario')
                .where({ Nome: nome })
                .first();

            if (!user) {
                return res.status(401).json({ error: 'Credenciais inválidas.' });
            }

            // CORREÇÃO DE SEGURANÇA: Bloqueia usuário inativo
            if (!user.Status) { 
                return res.status(401).json({ error: 'Usuário inativo. Acesso negado.' });
            }

            const isMatch = await bcrypt.compare(senha, user.Senha);

            if (!isMatch) {
                return res.status(401).json({ error: 'Credenciais inválidas.' });
            }

            const token = jwt.sign(
                { Id: user.Id, Nome: user.Nome }, 
                jwtSecret, 
                { expiresIn: '1h' }
            );

            return res.json({ token });

        } catch (error) {
            console.error('Erro no login:', error);
            return res.status(500).json({ error: 'Erro interno do servidor.' });
        }
    }, // <--- VÍRGULA ESSENCIAL SEPARANDO OS MÉTODOS

    // --- FUNÇÃO 2: VERIFICATOKEN (MIDDLEWARE) ---
    verificaToken(req, res, next) {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'Token não fornecido ou inválido.' });
        }

        const token = authHeader.split(' ')[1];

        jwt.verify(token, jwtSecret, (err, decoded) => {
            if (err) {
                return res.status(401).json({ error: 'Token inválido ou expirado.' });
            }
            // Anexa os dados do usuário ao request (útil para o rastreamento)
            req.userId = decoded.Id;
            req.userName = decoded.Nome; 
            return next(); // Prossegue para a próxima rota (Controller)
        });
    }
    // ---------------------------------------------
};

module.exports = authController;