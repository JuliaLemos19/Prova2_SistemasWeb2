const knex = require('../config/db');

const produtoController = {
    // READ: Listar todos os produtos (GET /api/produtos)
    async index(req, res) {
        try {
            const produtos = await knex('Produto').select('*');
            return res.json(produtos);
        } catch (error) {
            console.error('Erro ao listar produtos:', error);
            return res.status(500).json({ error: 'Erro interno ao listar produtos.' });
        }
    },

    // CREATE: Cadastrar um novo produto (POST /api/produtos)
    async create(req, res) {
        const { Nome, Preco, IdUsuarioCadastro } = req.body; 
        
        // Validação básica
        if (!Nome || !Preco) {
            return res.status(400).json({ error: 'Nome e Preço são obrigatórios.' });
        }

        // Assumindo que você tem o Id do usuário logado no token
        const IdUsuario = req.userId; // Vem do middleware verificaToken
        
        try {
            const [newId] = await knex('Produto').insert({
                Nome,
                Preco: parseFloat(Preco), // Garante que é um número
                IdUsuarioCadastro: IdUsuario,
                IdUsuarioUpdate: IdUsuario,
            });

            const novoProduto = await knex('Produto').where('Id', newId).first();
            return res.status(201).json(novoProduto);

        } catch (error) {
            console.error('Erro ao cadastrar produto:', error);
            return res.status(500).json({ error: 'Erro interno ao cadastrar produto.' });
        }
    },

    // UPDATE: Atualizar um produto (PUT /api/produtos/:id)
    async update(req, res) {
        const { id } = req.params;
        const { Nome, Preco } = req.body;
        
        // Assumindo que você tem o Id do usuário logado no token
        const IdUsuario = req.userId; // Vem do middleware verificaToken

        const updates = {};
        if (Nome) updates.Nome = Nome;
        if (Preco !== undefined) updates.Preco = parseFloat(Preco);
        
        // Sempre atualiza o usuário de modificação
        updates.IdUsuarioUpdate = IdUsuario;

        if (Object.keys(updates).length === 1) { // Só tem IdUsuarioUpdate, sem dados
            return res.status(400).json({ error: 'Nenhum dado válido para atualização.' });
        }

        try {
            const count = await knex('Produto')
                .where({ Id: id })
                .update(updates);

            if (count === 0) {
                return res.status(404).json({ error: 'Produto não encontrado.' });
            }

            const produtoAtualizado = await knex('Produto').where('Id', id).first();
            return res.json(produtoAtualizado);

        } catch (error) {
            console.error('Erro ao atualizar produto:', error);
            return res.status(500).json({ error: 'Erro interno ao atualizar produto.' });
        }
    },

    // DELETE: Deletar um produto (DELETE /api/produtos/:id)
    async destroy(req, res) {
        const { id } = req.params;
        try {
            const count = await knex('Produto')
                .where({ Id: id })
                .delete();

            if (count === 0) {
                return res.status(404).json({ error: 'Produto não encontrado.' });
            }

            return res.status(204).send(); // Sucesso sem conteúdo
        } catch (error) {
            console.error('Erro ao deletar produto:', error);
            return res.status(500).json({ error: 'Erro interno ao deletar produto.' });
        }
    }
};

module.exports = produtoController;