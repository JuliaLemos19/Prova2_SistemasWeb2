const knex = require('..\\config\\db');
const bcrypt = require('bcryptjs');

module.exports = {
    // 1. LISTAR TODOS OS USUÁRIOS (READ)
    async index(req, res) {
        try {
            const usuarios = await knex('Usuario')
                .select('Id', 'Nome', 'Status');
            
            return res.json(usuarios);
        } catch (error) {
            console.error('Erro ao listar usuários:', error);
            return res.status(500).json({ error: 'Erro interno do servidor.' });
        }
    },

    // 2. CRIAR NOVO USUÁRIO (CREATE)
    async create(req, res) {
        const { Nome, Senha, Status } = req.body;

        if (!Nome || !Senha) {
            return res.status(400).json({ error: 'Nome e Senha são obrigatórios.' });
        }

        try {
            const hash = await bcrypt.hash(Senha, 10);

            const [newId] = await knex('Usuario').insert({
                Nome,
                Senha: hash,
                Status: Status === undefined ? true : Status
            });

            return res.status(201).json({ 
                message: 'Usuário criado com sucesso!', 
                Id: newId 
            });

        } catch (error) {
            if (error.errno === 19 || error.code === 'SQLITE_CONSTRAINT') {
                return res.status(409).json({ error: 'Nome de usuário já existe.' });
            }
            console.error('Erro ao criar usuário:', error);
            return res.status(500).json({ error: 'Erro interno do servidor.' });
        }
    },

    // 3. ATUALIZAR USUÁRIO (UPDATE) - Inclui mudança de Status/Senha
    async update(req, res) {
        const { id } = req.params;
        const { Nome, Senha, Status } = req.body;
        
        const updateData = {};

        if (Nome !== undefined) {
            updateData.Nome = Nome;
        }

        if (Status !== undefined) {
            updateData.Status = Status;
        }

        if (Senha) {
            try {
                updateData.Senha = await bcrypt.hash(Senha, 10);
            } catch (error) {
                console.error('Erro ao hashear senha:', error);
                return res.status(500).json({ error: 'Falha ao processar a nova senha.' });
            }
        }
        
        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({ error: 'Nenhum campo válido para atualização fornecido.' });
        }

        try {
            const affectedRows = await knex('Usuario')
                .where({ Id: id })
                .update(updateData);
            
            if (affectedRows === 0) {
                return res.status(404).json({ error: 'Usuário não encontrado.' });
            }

            return res.json({ message: 'Usuário atualizado com sucesso!' });

        } catch (error) {
            console.error('Erro ao atualizar usuário:', error);
            return res.status(500).json({ error: 'Erro interno do servidor.' });
        }
    
    
    
    
    },

    async destroy(req, res) {
        const { id } = req.params;
        try {
            // Não permitimos que o usuário DELETE a si mesmo (o usuário logado)
            if (req.userId == id) {
                return res.status(403).json({ error: 'Não é possível deletar seu próprio usuário enquanto logado.' });
            }
            
            const count = await knex('Usuario')
                .where({ Id: id })
                .delete();

            if (count === 0) {
                return res.status(404).json({ error: 'Usuário não encontrado.' });
            }

            return res.status(204).send(); // Retorna 204 (No Content) em caso de sucesso

        } catch (error) {
            console.error('Erro ao deletar usuário:', error);
            return res.status(500).json({ error: 'Erro interno ao deletar usuário.' });
        }
    }
};