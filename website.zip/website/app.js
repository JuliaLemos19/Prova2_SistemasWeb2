const API_URL = 'http://localhost:3000/api';
let currentToken = localStorage.getItem('token') || null;

// --- Variável de Estado para Formulário ---
let isFormVisible = false;

// --- Funções de UI --- 
function updateWebUI() { 
    const loginSection = document.getElementById('login-section'); 
    const productManagement = document.getElementById('product-management'); 
    
    if (currentToken) { 
        loginSection.style.display = 'none'; 
        productManagement.style.display = 'block'; 
        loadProducts(); // Função principal para carregar os dados
    } else { 
        loginSection.style.display = 'block'; 
        productManagement.style.display = 'none'; 
        // Opcional: hideForm();
    } 
} 

function logout() { 
    localStorage.removeItem('token'); 
    currentToken = null; 
    updateWebUI(); 
} 

// --- Login (Chama a API para autenticar) --- 
async function handleLogin() { 
    const nome = document.getElementById('login-nome').value; 
    const senha = document.getElementById('login-senha').value; 
    const msg = document.getElementById('login-message'); 

    if (!nome || !senha) {
        msg.textContent = 'Nome e Senha são obrigatórios.';
        return;
    }
    
    try { 
        const response = await fetch(`${API_URL}/auth/login`, { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' }, 
            body: JSON.stringify({ nome, senha }) 
        }); 
        
        const data = await response.json(); 
        
        if (response.ok) { 
            localStorage.setItem('token', data.token); 
            currentToken = data.token; 
            msg.textContent = 'Login bem-sucedido!'; 
            updateWebUI(); // Atualiza a UI para mostrar a gestão de produtos
        } else { 
            msg.textContent = data.error || 'Erro no login.'; 
        } 
    } catch (e) { 
        msg.textContent = 'Erro de conexão com a API. Verifique se o servidor Node.js está rodando.'; 
    } 
} 

// --- CRUD de Produtos (Carregar) --- 
async function loadProducts() { 
    const tableBody = document.getElementById('product-table').querySelector('tbody'); 
    tableBody.innerHTML = '<tr><td colspan="4">Carregando produtos...</td></tr>';
    
    try { 
        const response = await fetch(`${API_URL}/produtos`, { 
            headers: { 'Authorization': `Bearer ${currentToken}` } 
        }); 
        
        const products = await response.json(); 
        
        tableBody.innerHTML = ''; 
        
        if (response.ok && products.length > 0) {
            products.forEach(p => { 
                const row = tableBody.insertRow(); 
                row.insertCell().textContent = p.Id; 
                row.insertCell().textContent = p.Nome; 
                row.insertCell().textContent = `R$ ${p.Preco.toFixed(2)}`; 
                
                const actionsCell = row.insertCell(); 
                // AQUI VOCÊ ADICIONARIA BOTÕES EDITAR E DELETAR PRODUTO
            }); 
        } else {
            tableBody.innerHTML = '<tr><td colspan="4">Nenhum produto encontrado.</td></tr>';
        }
        
    } catch (e) { 
        tableBody.innerHTML = '<tr><td colspan="4" style="color: red;">Erro ao carregar produtos. Acesso não autorizado?</td></tr>';
    } 
} 

// ... (Mantenha as funções handleLogin, updateWebUI, logout intactas no topo)

// --- Funções de Formulário ---
function updateFormVisibility() { 
    const formContainer = document.getElementById('product-form-container');
    const newProductBtn = document.querySelector('#product-management > button:first-of-type');
    if (newProductBtn && formContainer) {
        newProductBtn.style.display = isFormVisible ? 'none' : 'block'; 
        formContainer.style.display = isFormVisible ? 'block' : 'none';
    }
}

function showCreateForm() { 
    document.getElementById('form-title').textContent = 'Cadastrar'; 
    document.getElementById('product-id').value = ''; 
    document.getElementById('product-nome').value = ''; 
    document.getElementById('product-preco').value = ''; 
    
    isFormVisible = true;
    updateFormVisibility();
} 

function editProduct(product) { 
    document.getElementById('form-title').textContent = 'Editar'; 
    document.getElementById('product-id').value = product.Id; 
    document.getElementById('product-nome').value = product.Nome; 
    document.getElementById('product-preco').value = product.Preco; 
    
    isFormVisible = true;
    updateFormVisibility();
} 

function hideForm() { 
    isFormVisible = false;
    updateFormVisibility();
    document.getElementById('product-id').value = ''; 
    document.getElementById('product-nome').value = ''; 
    document.getElementById('product-preco').value = ''; 
    document.getElementById('form-title').textContent = 'Cadastrar';
} 

// --- CRUD de Produtos (Carregar) --- 
async function loadProducts() { 
    const tableBody = document.getElementById('product-table').querySelector('tbody'); 
    tableBody.innerHTML = '<tr><td colspan="4">Carregando produtos...</td></tr>';
    
    try { 
        const response = await fetch(`${API_URL}/produtos`, { 
            headers: { 'Authorization': `Bearer ${currentToken}` } 
        }); 
        
        const products = await response.json(); 
        
        tableBody.innerHTML = ''; 
        
        if (response.ok && products.length > 0) {
            products.forEach(p => { 
                const row = tableBody.insertRow(); 
                row.insertCell().textContent = p.Id; 
                row.insertCell().textContent = p.Nome; 
                // Formatação do preço
                row.insertCell().textContent = `R$ ${parseFloat(p.Preco).toFixed(2)}`; 
                
                const actionsCell = row.insertCell(); 
                
                // Botão Editar
                const editBtn = document.createElement('button'); 
                editBtn.textContent = 'Editar'; 
                editBtn.onclick = () => editProduct(p); 
                actionsCell.appendChild(editBtn); 

                // Botão Deletar
                const deleteBtn = document.createElement('button');
                deleteBtn.textContent = 'Deletar';
                deleteBtn.style.marginLeft = '5px';
                deleteBtn.onclick = () => deleteProduct(p.Id);
                actionsCell.appendChild(deleteBtn);
            }); 
        } else {
            tableBody.innerHTML = '<tr><td colspan="4">Nenhum produto encontrado.</td></tr>';
        }
        
    } catch (e) { 
        tableBody.innerHTML = '<tr><td colspan="4" style="color: red;">Erro ao carregar produtos.</td></tr>';
    } 
} 

// --- CRUD de Produtos (Salvar) ---
async function saveProduct() { 
    const id = document.getElementById('product-id').value; 
    const nome = document.getElementById('product-nome').value; 
    const preco = document.getElementById('product-preco').value; 
    const isEditing = !!id; 
    const method = isEditing ? 'PUT' : 'POST'; 
    const url = isEditing ? `${API_URL}/produtos/${id}` : `${API_URL}/produtos`; 
    
    if (!nome || !preco) {
        alert('Nome e Preço são obrigatórios.');
        return;
    }

    const payload = { 
        Nome: nome, 
        Preco: parseFloat(preco)
    };
    
    try { 
        const response = await fetch(url, { 
            method: method, 
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${currentToken}` }, 
            body: JSON.stringify(payload) 
        }); 
        
        if (response.ok) { 
            alert(`Produto ${isEditing ? 'atualizado' : 'cadastrado'} com sucesso!`); 
            loadProducts(); 
            hideForm(); 
        } else { 
            const errorData = await response.json(); 
            alert(`Erro: ${errorData.error || 'Falha na operação de produto.'}`);
        } 
    } catch (e) { 
        alert('Erro de conexão com a API ao salvar produto.'); 
    } 
} 

// --- CRUD de Produtos (Deletar) ---
async function deleteProduct(id) {
    if (!confirm('Tem certeza de que deseja deletar este produto?')) {
        return;
    }
    try {
        const response = await fetch(`${API_URL}/produtos/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${currentToken}` }
        });

        if (response.status === 204) { // 204 = No Content (Sucesso no DELETE)
            alert('Produto deletado com sucesso!');
            loadProducts(); 
        } else {
            const errorData = await response.json();
            alert(`Erro: ${errorData.error || 'Falha ao deletar produto.'}`);
        }
    } catch (e) {
        alert('Erro de conexão com a API ao deletar produto.');
    }
}
document.addEventListener('DOMContentLoaded', updateWebUI);