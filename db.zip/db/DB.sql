UPDATE Usuario
SET Senha = '$2b$10$LobL./BmByW4vS8L8D.nEuB58qPu19Ldp3P.HMuPcV6xyjYUccgOG'
WHERE Nome = 'admin';